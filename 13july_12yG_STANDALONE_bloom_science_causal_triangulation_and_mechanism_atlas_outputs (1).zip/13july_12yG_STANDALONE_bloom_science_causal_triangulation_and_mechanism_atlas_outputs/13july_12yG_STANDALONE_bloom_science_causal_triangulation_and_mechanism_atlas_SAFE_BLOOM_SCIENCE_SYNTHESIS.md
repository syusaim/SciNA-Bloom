# 13july_12yG_STANDALONE_bloom_science_causal_triangulation_and_mechanism_atlas: science-discovery synthesis

This analysis is post-hoc and read-only with respect to the frozen forecast model.

## Evidence hierarchy
1. Deterministic environmental proxies and time-ordered panel estimates.
2. First-difference within-lake estimates and negative-control placebos.
3. Frozen B2 named-concept interventions.
4. Replication across temporal/spatial development and locked domains.
5. Independent NLA microcystin criterion evidence.

## Mechanism grades
- **E01_thermal_current** — TRIANGULATED_TRANSPORTABLE_MECHANISM_CANDIDATE; 4/6 supportive channels.
- **E02_thermal_memory** — PROMISING_TRANSPORTABLE_MECHANISM_CANDIDATE; 3/6 supportive channels.
- **E03_light_season** — PROMISING_TRANSPORTABLE_MECHANISM_CANDIDATE; 3/5 supportive channels.
- **E04_stability** — PARTIAL_SUPPORT_REQUIRES_EXPERIMENT; 2/6 supportive channels.
- **E05_mixing_disruption** — PARTIAL_SUPPORT_REQUIRES_EXPERIMENT; 2/4 supportive channels.
- **E06_current_flushing** — PARTIAL_SUPPORT_REQUIRES_EXPERIMENT; 3/6 supportive channels.
- **E07_antecedent_flushing** — CONTEXT_DEPENDENT_TRANSPORTABLE_MECHANISM_CANDIDATE; 4/5 supportive channels.
- **E08_loading** — PROMISING_TRANSPORTABLE_MECHANISM_CANDIDATE; 3/6 supportive channels.
- **E09_buffering** — INSUFFICIENT_OR_MODEL_ONLY; 1/4 supportive channels.
- **E10_concentration_drying** — PARTIAL_SUPPORT_REQUIRES_EXPERIMENT; 2/6 supportive channels.

## Non-negotiable boundaries
- No result is causal proof.
- Frozen-model interventions are model sensitivities, not real-world treatment effects.
- NLA results are criterion evidence, not calibrated toxin forecasts.
- Collapse precursors do not identify ferroptosis or other cellular death pathways.
- The original 12yD/12yF forecast evidence remains unchanged and frozen.