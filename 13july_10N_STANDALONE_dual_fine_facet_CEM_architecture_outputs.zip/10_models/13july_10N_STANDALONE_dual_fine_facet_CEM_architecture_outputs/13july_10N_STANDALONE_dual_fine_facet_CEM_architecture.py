
from __future__ import annotations
from typing import Any, Dict, List, Optional
import re
import torch
import torch.nn as nn
import torch.nn.functional as F


def _safe_name(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_]+", "_", str(value)).strip("_")


class ExplicitFineFacetEncoder(nn.Module):
    """One aligned scalar plus a two-dimensional concept-confined embedding.

    No LayerNorm is applied across raw feature inputs, so common concept magnitude is preserved.
    """
    def __init__(self, n_features: int, embedding_dim: int = 2, hidden: int = 44, dropout: float = 0.08):
        super().__init__()
        if n_features < 1:
            raise ValueError("An active facet encoder needs at least one feature")
        self.n_features = int(n_features)
        self.embedding_dim = int(embedding_dim)
        h = max(16, min(int(hidden), 2 * self.n_features + 16))
        self.attention_logits = nn.Parameter(torch.zeros(self.n_features))
        self.backbone = nn.Sequential(
            nn.Linear(self.n_features + 4, h),
            nn.SiLU(),
            nn.Dropout(float(dropout)),
            nn.Linear(h, h),
            nn.SiLU(),
        )
        self.scalar_head = nn.Linear(h, 1)
        self.positive_prototype = nn.Linear(h, self.embedding_dim)
        self.negative_prototype = nn.Linear(h, self.embedding_dim)

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        attention = torch.softmax(self.attention_logits, dim=0)
        x_weighted = x * (attention * self.n_features).view(1, -1)
        stats = torch.cat([
            x_weighted.mean(dim=1, keepdim=True),
            x_weighted.std(dim=1, unbiased=False, keepdim=True),
            x_weighted.min(dim=1, keepdim=True).values,
            x_weighted.max(dim=1, keepdim=True).values,
        ], dim=1)
        h = self.backbone(torch.cat([x_weighted, stats], dim=1))
        scalar = torch.sigmoid(self.scalar_head(h).squeeze(-1))
        positive = torch.tanh(self.positive_prototype(h))
        negative = torch.tanh(self.negative_prototype(h))
        embedding = scalar.unsqueeze(1) * positive + (1.0 - scalar).unsqueeze(1) * negative
        return {
            "scalar": scalar,
            "embedding": embedding,
            "positive_prototype": positive,
            "negative_prototype": negative,
            "attention": attention,
        }


class GaussianMultitaskHead(nn.Module):
    def __init__(self, input_dim: int, hidden: int = 128, dropout: float = 0.08):
        super().__init__()
        h = max(48, int(hidden))
        self.shared = nn.Sequential(
            nn.Linear(int(input_dim), h),
            nn.SiLU(),
            nn.Dropout(float(dropout)),
            nn.Linear(h, h // 2),
            nn.SiLU(),
            nn.Dropout(float(dropout)),
        )
        self.output = nn.Linear(h // 2, 5)

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        raw = self.output(self.shared(x))
        return {
            "mu_scaled": raw[:, 0],
            "sigma_scaled": F.softplus(raw[:, 1]) + 0.05,
            "elevated_logit": raw[:, 2],
            "severe_logit": raw[:, 3],
            "lowtail_logit": raw[:, 4],
        }


class StateAwareProductCorrection(nn.Module):
    """Bounded B1 correction. All ecological state inputs must be detached by the caller."""
    def __init__(self, input_dim: int, hidden: int = 96, dropout: float = 0.08):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(int(input_dim), int(hidden)),
            nn.SiLU(),
            nn.Dropout(float(dropout)),
            nn.Linear(int(hidden), int(hidden) // 2),
            nn.SiLU(),
            nn.Linear(int(hidden) // 2, 5),
        )

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        raw = self.network(x)
        return {
            "delta_mu": 0.50 * torch.tanh(raw[:, 0]),
            "delta_log_sigma": 0.50 * torch.tanh(raw[:, 1]),
            "delta_elevated": 1.50 * torch.tanh(raw[:, 2]),
            "delta_severe": 1.50 * torch.tanh(raw[:, 3]),
            "delta_lowtail": 1.50 * torch.tanh(raw[:, 4]),
            "raw": raw,
        }


class DualFineFacetCEM(nn.Module):
    """Matched scientific B2 plus detached operational B1.

    B2 receives only named facet blocks and bounded C13 modulation.
    B1 receives detached B2 outputs, detached predictive parent state, C13, and C14.
    """
    def __init__(self, config: Dict[str, Any], enable_b1: bool = True):
        super().__init__()
        self.config = config
        self.input_dim = int(config["input_dim"])
        self.leaf_slot_count = int(config["leaf_slot_count"])
        self.group_slot_count = int(config["group_slot_count"])
        self.enable_b1 = bool(enable_b1)
        self.context_gate_scale = float(config["context_gate_scale"])
        self.context_shift_scale = float(config["context_shift_scale"])
        self.predictive_leaf_names = list(config["predictive_leaf_names"])
        self.primary_parent_names = list(config["primary_parent_names"])
        self.all_parent_names = list(config["all_parent_names"])
        self.leaf_specs = list(config["leaf_specs"])
        self.parent_specs = list(config["parent_specs"])

        self.register_buffer("context_indices", torch.tensor(config["context_feature_indices"], dtype=torch.long), persistent=True)
        self.register_buffer("support_indices", torch.tensor(config["support_feature_indices"], dtype=torch.long), persistent=True)
        self.encoders = nn.ModuleDict()
        self._index_buffer_names: Dict[str, str] = {}
        for j, spec in enumerate(self.leaf_specs):
            if not spec["active_encoder"]:
                continue
            name = spec["leaf_name"]
            self.encoders[name] = ExplicitFineFacetEncoder(
                n_features=len(spec["feature_indices"]),
                embedding_dim=int(spec.get("embedding_dim", 2)),
                hidden=int(config["facet_hidden"]),
                dropout=float(config["dropout"]),
            )
            buffer_name = f"leaf_feature_indices__{j}"
            self.register_buffer(buffer_name, torch.tensor(spec["feature_indices"], dtype=torch.long), persistent=True)
            self._index_buffer_names[name] = buffer_name

        block_dim = 1 + int(config["facet_embedding_dim"])
        self.context_gate = nn.Linear(len(config["context_feature_indices"]), len(self.predictive_leaf_names))
        self.context_shift = nn.Linear(len(config["context_feature_indices"]), len(self.predictive_leaf_names))
        self.b2_head = GaussianMultitaskHead(
            input_dim=len(self.predictive_leaf_names) * block_dim,
            hidden=int(config["b2_head_hidden"]),
            dropout=float(config["dropout"]),
        )
        if self.enable_b1:
            product_dim = len(config["support_feature_indices"]) + len(config["context_feature_indices"]) + 5 + len(self.primary_parent_names)
            self.b1_correction = StateAwareProductCorrection(
                input_dim=product_dim,
                hidden=int(config["b1_head_hidden"]),
                dropout=float(config["dropout"]),
            )

    def _apply_intervention(self, name: str, encoded: Dict[str, torch.Tensor], interventions: Optional[Dict[str, Dict[str, Any]]]):
        if not interventions or name not in interventions:
            return encoded
        rule = interventions[name]
        scalar = encoded["scalar"]
        embedding = encoded["embedding"]
        if "scalar" in rule:
            value = rule["scalar"]
            scalar = torch.full_like(scalar, float(value)) if not torch.is_tensor(value) else value.to(scalar)
        if rule.get("zero_embedding", False):
            embedding = torch.zeros_like(embedding)
        mode = rule.get("prototype")
        if mode == "positive":
            embedding = encoded["positive_prototype"]
        elif mode == "negative":
            embedding = encoded["negative_prototype"]
        return {**encoded, "scalar": scalar, "embedding": embedding}

    def _encode(self, x: torch.Tensor, interventions: Optional[Dict[str, Dict[str, Any]]] = None):
        score_by_name: Dict[str, torch.Tensor] = {}
        block_by_name: Dict[str, torch.Tensor] = {}
        attentions: Dict[str, torch.Tensor] = {}
        prototype_norm_terms: List[torch.Tensor] = []
        prototype_separation_terms: List[torch.Tensor] = []
        for spec in self.leaf_specs:
            name = spec["leaf_name"]
            if not spec["active_encoder"]:
                continue
            idx = getattr(self, self._index_buffer_names[name]).to(x.device)
            encoded = self.encoders[name](x.index_select(1, idx))
            encoded = self._apply_intervention(name, encoded, interventions)
            score_by_name[name] = encoded["scalar"]
            block_by_name[name] = torch.cat([encoded["scalar"].unsqueeze(1), encoded["embedding"]], dim=1)
            attentions[name] = encoded["attention"]
            prototype_norm_terms.append(encoded["positive_prototype"].pow(2).mean() + encoded["negative_prototype"].pow(2).mean())
            prototype_separation_terms.append(F.relu(0.5 - (encoded["positive_prototype"] - encoded["negative_prototype"]).norm(dim=1)).pow(2).mean())

        template = next(iter(score_by_name.values()))
        slots: List[torch.Tensor] = [torch.full_like(template, 0.5) for _ in range(self.leaf_slot_count)]
        for spec in self.leaf_specs:
            if spec["active_encoder"]:
                slots[int(spec["leaf_slot_index"])] = score_by_name[spec["leaf_name"]]
        leaf_scores_all_slots = torch.stack(slots, dim=1)

        parent_reporting = []
        parent_predictive = []
        primary_lookup = {name: i for i, name in enumerate(self.primary_parent_names)}
        predictive_by_primary: List[Optional[torch.Tensor]] = [None] * len(self.primary_parent_names)
        for parent in self.parent_specs:
            idx_all = torch.tensor(parent["all_leaf_slot_indices"], dtype=torch.long, device=x.device)
            w_all = torch.tensor(parent["all_leaf_weights"], dtype=x.dtype, device=x.device)
            report_score = (leaf_scores_all_slots.index_select(1, idx_all) * w_all.view(1, -1)).sum(dim=1)
            parent_reporting.append(report_score)
            if parent["is_primary_parent"]:
                idx_pred = torch.tensor(parent["predictive_leaf_slot_indices"], dtype=torch.long, device=x.device)
                w_pred = torch.tensor(parent["predictive_leaf_weights"], dtype=x.dtype, device=x.device)
                pred_score = (leaf_scores_all_slots.index_select(1, idx_pred) * w_pred.view(1, -1)).sum(dim=1)
                predictive_by_primary[primary_lookup[parent["parent_name"]]] = pred_score
        parent_scores_reporting = torch.stack(parent_reporting, dim=1)
        if any(v is None for v in predictive_by_primary):
            raise RuntimeError("A primary parent lacks a predictive route")
        parent_scores_predictive = torch.stack([v for v in predictive_by_primary if v is not None], dim=1)

        blocks = [block_by_name[name] for name in self.predictive_leaf_names]
        norm_penalty = torch.stack(prototype_norm_terms).mean() if prototype_norm_terms else x.new_tensor(0.0)
        separation_penalty = torch.stack(prototype_separation_terms).mean() if prototype_separation_terms else x.new_tensor(0.0)
        return {
            "leaf_scores_all_slots": leaf_scores_all_slots,
            "parent_scores_reporting": parent_scores_reporting,
            "parent_scores_predictive": parent_scores_predictive,
            "predictive_blocks": blocks,
            "feature_attention": attentions,
            "prototype_norm_penalty": norm_penalty,
            "prototype_separation_penalty": separation_penalty,
        }

    def forward(self, x: torch.Tensor, interventions: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
        if x.ndim != 2 or x.shape[1] != self.input_dim:
            raise ValueError(f"Expected [batch,{self.input_dim}] input, got {tuple(x.shape)}")
        encoded = self._encode(x, interventions=interventions)
        context = x.index_select(1, self.context_indices.to(x.device))
        gate = 1.0 + self.context_gate_scale * torch.tanh(self.context_gate(context))
        shift = self.context_shift_scale * torch.tanh(self.context_shift(context))
        modified_blocks = []
        for j, block in enumerate(encoded["predictive_blocks"]):
            b = block * gate[:, j:j+1]
            b = torch.cat([(b[:, 0] + shift[:, j]).unsqueeze(1), b[:, 1:]], dim=1)
            modified_blocks.append(b)
        b2 = self.b2_head(torch.cat(modified_blocks, dim=1))
        out: Dict[str, Any] = {
            "b2": b2,
            **encoded,
            "context_gate": gate,
            "context_shift": shift,
            "modified_predictive_blocks": modified_blocks,
        }
        if self.enable_b1:
            support = x.index_select(1, self.support_indices.to(x.device))
            base = torch.stack([
                b2["mu_scaled"],
                torch.log(b2["sigma_scaled"]),
                b2["elevated_logit"],
                b2["severe_logit"],
                b2["lowtail_logit"],
            ], dim=1).detach()
            state = encoded["parent_scores_predictive"].detach()
            correction = self.b1_correction(torch.cat([support, context, base, state], dim=1))
            out["b1"] = {
                "mu_scaled": b2["mu_scaled"].detach() + correction["delta_mu"],
                "sigma_scaled": torch.clamp(b2["sigma_scaled"].detach() * torch.exp(correction["delta_log_sigma"]), 0.03, 3.0),
                "elevated_logit": b2["elevated_logit"].detach() + correction["delta_elevated"],
                "severe_logit": b2["severe_logit"].detach() + correction["delta_severe"],
                "lowtail_logit": b2["lowtail_logit"].detach() + correction["delta_lowtail"],
                "correction_raw": correction["raw"],
                "detached_parent_state": state,
            }
        return out

    def encoder_parameters(self):
        return self.encoders.parameters()

    def b2_head_parameters(self):
        for module in [self.context_gate, self.context_shift, self.b2_head]:
            yield from module.parameters()

    def b1_head_parameters(self):
        if self.enable_b1:
            yield from self.b1_correction.parameters()
