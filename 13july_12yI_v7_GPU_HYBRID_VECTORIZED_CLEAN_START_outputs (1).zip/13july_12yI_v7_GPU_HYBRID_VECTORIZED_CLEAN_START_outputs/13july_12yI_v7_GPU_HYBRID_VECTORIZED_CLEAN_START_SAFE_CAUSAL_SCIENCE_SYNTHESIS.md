# 12yI v7 hybrid directional causal graph summary

- The forecasting ensemble, thresholds, seeds, splits, and predeclared causal questions remained frozen. No forecast training, seed selection, or threshold tuning occurred.
- This is a clean-start experiment in a new output directory; no v2–v6 causal-result caches were imported.
- Vector backend: cuda:0 (NVIDIA RTX PRO 6000 Blackwell Server Edition); all accelerated statistical kernels used float64.
- Small adaptive PCMCI+ rows: 785; predeclared targeted MCI rows: 90; LPCMCI rows: 124.
- Natural-event rows: 448; pathway rows: 24; invariance rows: 585.
- Held-out edge-direction accuracy: 0.75.
- NLA post-balance max |SMD|: 0.000; minimum group ESS: 9.7.
- Evidence grades: {'TRIANGULATED_DIRECTIONAL_MECHANISM_CANDIDATE': 10, 'STRONG_TRANSPORTABLE_QUASI_CAUSAL_PATHWAY': 3, 'PROMISING_BUT_INCOMPLETE': 3, 'NOT_SUPPORTED_OR_UNRESOLVED': 1, 'EXTERNAL_CRITERION_SUPPORTED': 1}.
- Targeted MCI is a predeclared conditional-independence hypothesis test; it is not presented as unrestricted all-to-all network discovery.
- The resulting graph contains transportable quasi-causal pathway candidates, not randomized experimental proof.
- The three experiment blueprints are the required bridge to intervention-level causal confirmation.