# Frozen manuscript evidence summary

## Confirmatory foundation
- B1 temporal-locked: elevated AP 0.883, severe AP 0.754, R² 0.661.
- B1 spatial-locked: elevated AP 0.740, severe AP 0.510, R² 0.500.
- B2 temporal-locked: elevated AP 0.812, severe AP 0.671, R² 0.571.
- B2 spatial-locked: elevated AP 0.625, severe AP 0.435, R² 0.350.

## Biologically motivated June–October secondary analysis
- B1 temporal-locked: elevated AP 0.917, severe AP 0.759, R² 0.680.
- B1 spatial-locked: elevated AP 0.807, severe AP 0.554, R² 0.543.
- B2 temporal-locked: elevated AP 0.854, severe AP 0.671, R² 0.581.
- B2 spatial-locked: elevated AP 0.701, severe AP 0.486, R² 0.378.

## Independent NLA in-situ criterion validation
- B2: detection AP 0.742, AUC 0.662, Spearman 0.406; 72 lakes.
- B1: detection AP 0.743, AUC 0.693, Spearman 0.454; 72 lakes.

## Interpretation boundaries
- B1 is the main operational model and includes a detached observation-reliability correction.
- B2 is the support-free ecological ablation; it is not causal proof.
- NLA results are independent in-situ criterion validation, not calibrated toxin probabilities.
- All seasonal, ACF, context, confidence, and state-transition findings are post-hoc exploratory.
- The frozen ensemble must not be retrained, reselected, or retuned after 12yD.