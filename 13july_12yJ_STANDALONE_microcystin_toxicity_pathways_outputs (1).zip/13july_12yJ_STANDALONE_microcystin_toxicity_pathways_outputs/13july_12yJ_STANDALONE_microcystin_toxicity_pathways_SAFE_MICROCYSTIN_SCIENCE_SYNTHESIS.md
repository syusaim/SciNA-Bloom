# 12yJ microcystin toxicity-pathway synthesis

- Primary fixed cohort: 73 lake-dates from 72 lakes; detections: 40.
- Strict prospective subset: 57 lake-dates from 56 lakes.
- The frozen SMN and the 12yD external criterion result were not altered.
- Primary external effects are reported both before and after conditioning on frozen B2 biomass.
- Conditional associations are toxicity-enabling candidates, not randomized causal proof.
- Falling-bloom findings are collapse-associated candidates; they do not identify lysis, ferroptosis, or toxin release without dissolved/particulate toxin and cellular measurements.

## Evidence grades

- **thermal_activation** — EXTERNAL_TOXICITY_ENABLING_CANDIDATE; conditional effect=0.2975 per fit SD; intensify toxin sampling after thermal activation and sustained warming.
- **hydrologic_delivery_flushing** — PROMISING_CONTEXT_DEPENDENT_TOXICITY_SIGNAL; conditional effect=-0.1078 per fit SD; separate immediate flushing from delayed delivery in post-storm monitoring.
- **nitrogen_loading** — PROMISING_CONTEXT_DEPENDENT_TOXICITY_SIGNAL; conditional effect=0.0594 per fit SD; test atmospheric and watershed N reductions jointly with warming.
- **mixing_redistribution** — EXTERNAL_TOXICITY_ENABLING_CANDIDATE; conditional effect=0.1614 per fit SD; use multi-depth sampling after strong wind instead of assuming bloom disappearance.
- **natural_buffering** — EXTERNAL_TOXICITY_ENABLING_CANDIDATE; conditional effect=-0.1286 per fit SD; identify lakes where natural buffering lowers bloom-linked toxin risk.
- **concentration_drying** — PROMISING_CONTEXT_DEPENDENT_TOXICITY_SIGNAL; conditional effect=-0.0518 per fit SD; target drought/retention experiments where concentration may sustain exposure.
- **falling_bloom_trajectory** — COLLAPSE_ASSOCIATION_NOT_RESOLVED; conditional effect=-0.0918 per fit SD; continue toxin sampling when satellite biomass falls.

## Interpretation boundary

The primary NLA detection analysis is independent biological criterion validation. The detailed physical niche and interaction analyses are targeted post-hoc external analyses. They should be used to define follow-up sampling and mesocosm experiments, not to claim toxin-production genes or cellular death mechanisms that were not measured.