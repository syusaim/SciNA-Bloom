# 12yH physical-unit causal analysis - finalized from existing results

- The original long run completed the expensive H1-H6 analyses and stopped in the final Q9 synthesis cell.
- This patch did not recompute any causal estimator or change any result.
- The Q9 mapping now handles interactions with no corresponding frozen B2 surface explicitly.
- All causal language remains quasi-causal/triangulated; experimental confirmation is still required.
- Exact NLA mean balance is reported, but weight stability/ESS remains required before a strong toxin-mechanism claim.